package domain;

import java.awt.Rectangle;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.font.TextLayout;
import java.awt.font.TextAttribute;
import java.awt.font.LineBreakMeasurer;
import java.awt.font.FontRenderContext;
import java.awt.geom.Rectangle2D;
import java.awt.image.ImageObserver;
import java.text.AttributedString;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

/* A text item.
   A domain.TextItem has drawing functionality.

 * @author Ian F. Darwin, ian@darwinsys.com, Gert Florijn, Sylvia Stuurman
 * @version 1.1 2002/12/17 Gert Florijn
 * @version 1.2 2003/11/19 Sylvia Stuurman
 * @version 1.3 2004/08/17 Sylvia Stuurman
 * @version 1.4 2007/07/16 Sylvia Stuurman
 * @version 1.5 2010/03/03 Sylvia Stuurman
 * @version 1.6 2014/05/16 Sylvia Stuurman
 */

public class TextItem extends SlideItem
{
	private String text;

	private static final String EMPTYTEXT = "No Text Given";

	protected static final String XML_KIND = "text";

	// a textitem of level level, with the text string
	public TextItem(int level, String string)
	{
		super(level);
		text = string;
	}

	// an empty textitem
	public TextItem()
	{
		this(0, EMPTYTEXT);
	}

	// give the text
	public String getText()
	{
		return text == null ? "" : text;
	}

	// give the AttributedString for the item
	public AttributedString getAttributedString(Style style, float scale)
	{
		// Guard against empty text: AttributedString.addAttribute requires
		// endIndex > beginIndex, so an empty string would otherwise throw
		// an IllegalArgumentException here. This is a pre-existing defect
		// in the original code (text.length() was called instead of the
		// null-safe getText(), and no empty-string guard existed),
		// surfaced when a text item with no content is loaded from XML.
		String content = getText();
		if (content.length() == 0)
		{
			content = " ";
		}
		AttributedString attrStr = new AttributedString(content);
		attrStr.addAttribute(TextAttribute.FONT, style.getFont(scale), 0, content.length());
		return attrStr;
	}

	// give the bounding box of the item
	public Rectangle getBoundingBox(Graphics g, ImageObserver observer,
	                                float scale, Style myStyle)
	{
		List<TextLayout> layouts = getLayouts(g, myStyle, scale);
		int xsize = 0, ysize = (int) (myStyle.leading * scale);
		Iterator<TextLayout> iterator = layouts.iterator();
		while (iterator.hasNext())
		{
			TextLayout layout = iterator.next();
			Rectangle2D bounds = layout.getBounds();
			if (bounds.getWidth() > xsize)
			{
				xsize = (int) bounds.getWidth();
			}
			if (bounds.getHeight() > 0)
			{
				ysize += bounds.getHeight();
			}
			ysize += layout.getLeading() + layout.getDescent();
		}
		return new Rectangle((int) (myStyle.indent * scale), 0, xsize, ysize);
	}

	// draw the item
	public void draw(int x, int y, float scale, Graphics g,
	                 Style myStyle, ImageObserver o)
	{
		if (text == null || text.length() == 0)
		{
			return;
		}
		List<TextLayout> layouts = getLayouts(g, myStyle, scale);
		Point pen = new Point(x + (int) (myStyle.indent * scale),
			y + (int) (myStyle.leading * scale));
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(myStyle.color);
		Iterator<TextLayout> it = layouts.iterator();
		while (it.hasNext())
		{
			TextLayout layout = it.next();
			pen.y += layout.getAscent();
			layout.draw(g2d, pen.x, pen.y);
			pen.y += layout.getDescent();
		}
	}

	private List<TextLayout> getLayouts(Graphics g, Style s, float scale)
	{
		List<TextLayout> layouts = new ArrayList<TextLayout>();
		AttributedString attrStr = getAttributedString(s, scale);
		Graphics2D g2d = (Graphics2D) g;
		FontRenderContext frc = g2d.getFontRenderContext();
		LineBreakMeasurer measurer = new LineBreakMeasurer(attrStr.getIterator(), frc);
		float wrappingWidth = (Slide.WIDTH - s.indent) * scale;
		while (measurer.getPosition() < getText().length())
		{
			TextLayout layout = measurer.nextLayout(wrappingWidth);
			layouts.add(layout);
		}
		return layouts;
	}

	public String toString()
	{
		return "TextItem[" + getLevel() + "," + getText() + "]";
	}

	// give the XML "kind" attribute value for this item
	public String getXMLKind()
	{
		return XML_KIND;
	}

	// give the text content to write inside the XML <item> element
	public String getXMLContent()
	{
		return getText();
	}
}
